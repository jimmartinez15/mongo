package com.aleal.empleados.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleadosBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleadosBackendApplication.class, args);
	}

}
