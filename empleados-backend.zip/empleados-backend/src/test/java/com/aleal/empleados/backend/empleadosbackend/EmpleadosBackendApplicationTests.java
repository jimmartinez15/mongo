package com.aleal.empleados.backend.empleadosbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadosBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
